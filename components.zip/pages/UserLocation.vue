


<template>
    <section class="ui two column centered grid">
        <div class="column">
            <form calss="ui segment large form">
                <div class="ui message red"></div>
                <div class="ui segment">
                    <div class="field">

                    </div>
                </div>
                    
            </form>
        </div>    
    </section>
    
</template>